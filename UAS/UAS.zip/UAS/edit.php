<?php require 'functions.php';

$id = $_GET["id"];
$psn = query("SELECT * FROM pasien WHERE id =$id")[0];

if(isset($_POST["submit"])){
	if(edit($_POST) > 0){
		echo "
			<script>
				alert ('Data berhasil diedit');
				document.location.href = 'index.php';
			</script>
		";
	}else{
		echo "
			<script>
				alert ('Data gagal diedit');
				document.location.href = 'index.php';
			</script>
		";
	}
}
?>
<html>
<head>
	<title>Edit Data Pasien</title>
</head>
<body>
	<h1>Edit Data Pasien</h1>
	<form action="" method="POST" enctype="multipart/form-data">
		<input type='hidden' name='id' value="<?= $psn["id"];?>">
		<ul>
			<li>
				<label for="nama_pasien">Nama :</label>
				<input type="text" name="nama_pasien" id="nama_pasien" required value="<?= $psn["nama_pasien"];?>"/>
			</li>
			<li>
				<label for="jenis_kelamin">jenis_kelamin :</label>
				<input type="text" name="jenis_kelamin" id="jenis_kelamin" required value="<?= $psn["jenis_kelamin"];?>"/>
			</li>
			<li>
				<label for="alamat">alamat :</label>
				<input type="text" name="alamat" id="alamat" required value="<?= $psn["alamat"];?>"/>
			</li>
			<li>
				<label for="keluhan">keluhan :</label>
				<input type="text" name="keluhan" id="keluhan" required value="<?= $psn["keluhan"];?>"/>
			</li>

			<li>
				<label for="nama_dokter">nama_dokter :</label>
				<input type="text" name="nama_dokter" id="nama_dokter" required value="<?= $psn["nama_dokter"];?>"/>
			</li>
			<li>
				<label for="nama_ruang">nama_ruang :</label>
				<input type="text" name="nama_ruang" id="nama_ruang" required value="<?= $psn["nama_ruang"];?>"/>
			</li>
				<button type="submit" name="submit">Edit Data</button>
			</li>
		</ul>
	</form>
</body>
</html>