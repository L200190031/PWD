<?php
    session_start();
    if(!isset($_SESSION["login"])) {
        header("Location: login.php");
        exit;
    }
	require "functions.php";
	$pasien = query("SELECT * FROM pasien");

    //tekan tombol cari
    if (isset ($_POST["cari"])) {
        $pasien = cari($_POST["keyword"]);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Halaman Admin</title>
</head>
<body>
    <?php include "bootstrap/imgcap.php"; ?>
    <?php include "bootstrap/navbar.php"; ?>
    <?php include "bootstrap/button.php"; ?>
    <br>
    <form action="" method="POST">

    </form>
    <br>
    <div id="container">
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>No</th>       
            <th>Nama Pasien</th>
            <th>Jenis Kelamin</th>
            <th>Alamat</th>
            <th>Keluhan</th>    
            <th>Nama Dokter</th>
            <th>Nama Ruang</th>
            <th>Aksi</th>

        </tr>
        <?php $i = 1 ?>
        <?php foreach ($pasien as $row) : ?>
        <tr>
            <td><?= $i ?></td>
            

            <td><?= $row["nama_pasien"]; ?></td>
            <td><?= $row["jenis_kelamin"]; ?></td>
            <td><?= $row["alamat"]; ?></td>
            <td><?= $row["keluhan"]; ?></td>
            <td><?= $row["nama_dokter"]; ?></td>
            <td><?= $row["nama_ruang"]; ?></td>
            
            <td><a href="edit.php?id=<?= $row["id"];?>">Edit</a> |
            <a href="hapus.php?id=<?= $row["id"];?>" onclick="return confirm('apakah anda ingin menghapus data?');">Hapus</a></td>
        </tr>
        <?php $i++ ?>
        <?php endforeach; ?>
    </table>
    </div>
    <script type="text/javascript" src="js/script.js"></script>
</body>
</html>