<?php
require 'vendor/autoload.php';
$conn = mysqli_connect("localhost", "root", "", "kesehatan_pwd");
$cari = "SELECT * FROM pasien";
$pasien = mysqli_query($conn, $cari);

// reference the Dompdf namespace
use Dompdf\Dompdf;

// instantiate and use the dompdf class
$dompdf = new Dompdf();

$html = '<!DOCTYPE html>
<html>
<head>
    <title>Daftar Pasien</title>
</head>
<body>
    <h1>Daftar Pasien</h1>
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>No</th>       
            <th>Nama Pasien</th>
            <th>Jenis Kelamin</th>
            <th>Alamat</th>
            <th>Keluhan</th>
            <th>Nama Dokter</th>
            <th>Nama Ruang</th>

        </tr>';
        $i = 1;
        foreach ($pasien as $row) {
            $html .='<tr>
                        <td>'.$i++.'</td>
                        <td>'.$row["nama_pasien"].'</td>
                        <td>'.$row["jenis_kelamin"].'</td>
                        <td>'.$row["alamat"].'</td>
                        <td>'.$row["keluhan"].'</td>
                        <td>'.$row["nama_dokter"].'</td>
                        <td>'.$row["nama_ruang"].'</td>
                    </tr>';
        }

        $html .='</table>
        </body>
        </html>';

$dompdf->loadHtml($html);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'landscape');

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
$dompdf->stream();

?>