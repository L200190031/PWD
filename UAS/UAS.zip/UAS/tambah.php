<?php
require 'functions.php';

//cek tombol submit sudah ditekan atau belom
if (isset($_POST["submit"])) {
    //cek jika berhasil ditambahkan
    if (tambah($_POST) > 0){
        echo 
            "<script>
				alert('Data berhasil ditambahkan');
				document.location.href = 'index.php';
			</script> ";
    }else{
        echo 
            "<script>
				alert('Data gagal untuk ditambahkan');
				document.location.href = 'index.php';
			</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah data Pasien</title>
</head>
<body>
    <h1>Tambah Data Pasien</h1>

    <form action="" method="POST">
    <ul>
        <li>
            <label for="nama_pasien">nama_pasien :</label>
            <input type="text" name="nama_pasien" id="nama_pasien" required/>
        </li>
        <li>
            <label for="jenis_kelamin">jenis_kelamin :</label>
            <input type="text" name="jenis_kelamin" id="jenis_kelamin" required/>
        </li>
        <li>
            <label for="alamat">alamat :</label>
            <input type="text" name="alamat" id="alamat" required/>
        </li>
        <li>
            <label for="keluhan">keluhan :</label>
            <input type="text" name="keluhan" id="keluhan" required/>
        </li>
        <li>
            <label for="nama_dokter">nama_dokter :</label>
            <input type="text" name="nama_dokter" id="nama_dokter" required/>
        </li>
        <li>
            <label for="nama_ruang">nama_ruang :</label>
            <input type="text" name="nama_ruang" id="nama_ruang" required/>
        </li>

        <button type="submit" name="submit">Tambah Data</button>
        </li>
    </ul>
    </form>
</body>
</html>