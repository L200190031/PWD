<?php
    $conn = mysqli_connect("localhost", "root", "", "kesehatan_pwd");

    function query($query) {
        global $conn;
        $result = mysqli_query($conn, $query);
        $rows = [];

        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        return $rows;
    }
    
    function registrasi($data){
        global $conn;

        $username = strtolower($data["username"]);
        $password = mysqli_real_escape_string($conn, $data["password"]);
        $password2 = mysqli_real_escape_string($conn, $data["password2"]);

        //Cek Username
        $result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
        if (mysqli_fetch_assoc($result)){
            echo "<script>
                    alert('Username Sudah Terdaftar')
                    </script>";
            return false;
        }

        //Cek Konfirmasi Password
        if ($password !== $password2) {
            echo "<script>
                    alert('Konfirmasi Password Tidak Sesuai')
                </script>";
            return false;
        }

        //Enkripsi Password
        $password = password_hash($password, PASSWORD_DEFAULT);

        //Tambahkan User Baru Ke DB
        mysqli_query($conn,"INSERT INTO user VALUES('','$username','$password')");
        return mysqli_affected_rows($conn);
    }

    function cari($keyword){
        $query = "SELECT * FROM pasien WHERE 
                    nama_pasien LIKE '%$keyword%' OR
                    jenis_kelamin LIKE '%$keyword%' OR
                    alamat LIKE '%$keyword%' OR
                    keluhan LIKE '%$keyword%' OR
                    nama_ruang LIKE '%$keyword%' OR
                    nama_dokter LIKE '%$keyword%'
        ";
        return query($query);
    }
    //HAPUS
    function hapus($id){
        global $conn;
        mysqli_query($conn, "DELETE FROM pasien WHERE id = $id");
        return mysqli_affected_rows($conn);
    }

    //EDIT
    function edit($data){
        global $conn;
        $id = $data["id"];
        $nama_pasien = htmlspecialchars($data["nama_pasien"]);
        $jenis_kelamin = htmlspecialchars($data["jenis_kelamin"]);
        $alamat = htmlspecialchars($data["alamat"]);
        $keluhan = htmlspecialchars($data["keluhan"]);
        $diagnosa_penyakit = htmlspecialchars($data["diagnosa_penyakit"]);
        $nama_dokter = htmlspecialchars($data["nama_dokter"]);
        $nama_ruang = htmlspecialchars($data["nama_ruang"]);       
        $query = "UPDATE pasien SET 
                    nama_pasien = '$nama_pasien', jenis_kelamin = '$jenis_kelamin', alamat = '$alamat', 
                    keluhan = '$keluhan', diagnosa_penyakit = '$diagnosa_penyakit', nama_dokter = '$nama_dokter', nama_ruang = '$nama_ruang' WHERE id = '$id'
                ";
        mysqli_query($conn, $query);
        
        
        return mysqli_affected_rows($conn);
    }
    function tambah($data){
        global $conn; 

        $id = $data["id"];
        $nama_pasien = htmlspecialchars($data["nama_pasien"]);
        $jenis_kelamin = htmlspecialchars($data["jenis_kelamin"]);
        $alamat = htmlspecialchars($data["alamat"]);
        $keluhan = htmlspecialchars($data["keluhan"]);
        $nama_dokter = htmlspecialchars($data["nama_dokter"]);
        $nama_ruang = htmlspecialchars($data["nama_ruang"]);  
    
        //melakukan insert data
        $query = "INSERT INTO pasien (id, nama_pasien, jenis_kelamin, alamat, keluhan, nama_dokter, nama_ruang) 
        VALUES('','$nama_pasien','$jenis_kelamin','$alamat','$keluhan','$nama_dokter','$nama_ruang')";
        mysqli_query($conn,$query);

        $query1 = "INSERT INTO pembayaran (id, nama_dokter , nama_ruang , nama_pasien) 
        VALUES('','$nama_dokter','$nama_ruang','$nama_pasien')";
        mysqli_query($conn,$query1);

        return mysqli_affected_rows($conn);
    }
?>