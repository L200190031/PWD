<?php
require "script.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <a href="tambah.php" type="button" class="btn btn-outline-primary">Tambah Pasien</a>
    <a href="cetak.php"" type="button" class="btn btn-outline-primary">Cetak ke PDF</a>
    <a href="logout.php" type="button" class="btn btn-outline-primary">Log out</a>

</body>
</html>
