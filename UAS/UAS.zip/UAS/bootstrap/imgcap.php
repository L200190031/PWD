<?php
require "script.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
<div class="card mb-3">
  <div class="card-body">
    <h2 class="card-title">Halaman Admin</h2>
    <p class="card-text">Selamat datang dihalaman admin, silahkan akses fitur disini !</p>
  </div>
</div>
</body>
</html>
