<?php
require "script.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">

      <form class="d-flex">
        <input class="form-control me-2" type="text" name="keyword" size="40" autofocus placeholder="Masukkan Kata Pencarian" autocomplete="off" id="keyword">
        <a class="btn btn-outline-success" type="text">Silahkan ketik untuk mencari</a>
      </form>
    </div>
  </div>
</nav>
</body>
</html>
