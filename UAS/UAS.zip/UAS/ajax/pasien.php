<?php
	require "../functions.php";
	
	$keyword = $_GET["keyword"];
    $query = "SELECT * FROM pasien WHERE 
    nama_pasien LIKE '%$keyword%' OR
    jenis_kelamin LIKE '%$keyword%' OR
    alamat LIKE '%$keyword%' OR
    keluhan LIKE '%$keyword%' OR
    nama_dokter LIKE '%$keyword%' OR
    nama_ruang LIKE '%$keyword%'
    ";
	$pasien = query($query);
?>

<table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>No</th>       
            <th>Nama Pasien</th>
            <th>Jenis Kelamin</th>
            <th>Alamat</th>
            <th>Keluhan</th>
            <th>Nama Dokter</th>
            <th>Nama Ruang/th>

        </tr>
        <?php $i = 1 ?>
        <?php foreach ($pasien as $row) : ?>
        <tr>
        <td><?= $row["nama_pasien"]; ?></td>
            <td><?= $row["jenis_kelamin"]; ?></td>
            <td><?= $row["alamat"]; ?></td>
            <td><?= $row["keluhan"]; ?></td>
            <td><?= $row["nama_dokter"]; ?></td>
            <td><?= $row["nama_ruang"]; ?></td>
        </tr>
        <?php $i++ ?>
        <?php endforeach; ?>
    </table>