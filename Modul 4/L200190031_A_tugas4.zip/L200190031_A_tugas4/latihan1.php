<?php
//L200190031
$array = [215, 367, 234, 555, 122, 899, 200, 194, 420, 98]; 
		echo "Nilai Maksimum dan Minimum dari: 215, 367, 234, 555, 122, 899, 200, 194, 420, 98" ;
		echo "<br>"."<br>"; 
		echo "Nilai Minimum : ".min($array); 
		echo "<br>"; 
		echo "Nilai Maksimum : ".max($array); 

?>