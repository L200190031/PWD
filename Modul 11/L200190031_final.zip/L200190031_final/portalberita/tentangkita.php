<!DOCTYPE html>
<html>
<head>
	<title>Tentang Kita</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
	<link rel="stylesheet" type="text/css" href="assets/about.css">
</head>	
<body>
    
	<div class="section">
		<div class="container">
			<div class="content-section">
				<div class="title">
					<h1>Tentang Kita</h1>
				</div>
				<div class="content">
					<h3>
                        <table border="0" width="500px">
                            <tr>
                                <td>Nama</td>
                                <td width="20px">:</td>
                                <td>Daffa Putra Alwansyah</td>
                            </tr> 
                            <tr>
                                <td>NIM</td>
                                <td width="20px">:</td>
                                <td>L200190031</td>
                            </tr> 
                            <tr>
                                <td>Prodi</td>
                                <td width="20px">:</td>
                                <td>Informatika</td>
                            </tr> 

                        </table>
                    </h3>
                    <h3>
                        Hai panggil aku Daffa, senang berkenalan denganmu!
                    <div class="button">
						<a href="index.php">Home</a>
					</div>
                    

				</div>

			</div>
			<div class="image-section">
				<img src="image/about.png">
			</div>
		</div>
	</div>

	
</body>
</html>